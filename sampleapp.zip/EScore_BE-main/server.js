const app = require('./app');
const config = require('./src/config/env.config');
const connectDB = require('./src/config/database');
const { verifySlackConnection } = require('./src/config/slack.config');
const logger = require('./src/utils/logger');
const fs = require('fs');
const path = require('path');

// Create logs directory if it doesn't exist
const logsDir = path.join(__dirname, '../logs');
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir, { recursive: true });
  logger.info('Logs directory created');
}

let server;

const startServer = async () => {
  try {
    // Connect to MongoDB
    logger.info('Connecting to MongoDB...');
    await connectDB();

    // Verify Slack connection before starting server
    logger.info('Verifying Slack connection...');
    await verifySlackConnection();

    // Start Express server
    server = app.listen(config.PORT, () => {
      logger.info('='.repeat(50));
      logger.info('🚀One Score API Started Successfully');
      logger.info('='.repeat(50));
      logger.info(`Environment: ${config.NODE_ENV}`);
      logger.info(`Port: ${config.PORT}`);
      logger.info(`API Version: ${config.API_VERSION}`);
      logger.info(`API Base URL: http://localhost:${config.PORT}/api/${config.API_VERSION}`);
      logger.info('='.repeat(50));
      logger.info('Available Endpoints:');
      logger.info(`  GET  /api/${config.API_VERSION}/health`);
      logger.info(`  POST /api/${config.API_VERSION}/channels`);
      logger.info('='.repeat(50));
    });

    server.on('error', (error) => {
      if (error.code === 'EADDRINUSE') {
        logger.error(`Port ${config.PORT} is already in use`);
        process.exit(1);
      } else {
        logger.error('Server error', { error: error.message });
        process.exit(1);
      }
    });

  } catch (error) {
    logger.error('Failed to start server', { 
      error: error.message,
      stack: error.stack 
    });
    process.exit(1);
  }
};

// Graceful shutdown
const gracefulShutdown = (signal) => {
  logger.info(`${signal} received. Shutting down gracefully...`);
  if (server) {
    server.close(() => {
      logger.info('Server closed. Process terminating...');
      process.exit(0);
    });

    setTimeout(() => {
      logger.error('Forcefully shutting down after timeout');
      process.exit(1);
    }, 5000);
  } else {
    process.exit(0);
  }
};

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));
process.on('SIGUSR2', () => gracefulShutdown('SIGUSR2'));

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
  logger.error('Uncaught Exception', { 
    error: error.message,
    stack: error.stack 
  });
  process.exit(1);
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  logger.error('Unhandled Rejection', { 
    reason,
    promise 
  });
  process.exit(1);
});

startServer();