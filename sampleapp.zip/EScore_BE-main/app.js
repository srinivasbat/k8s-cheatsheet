require('express-async-errors');
const express = require('express');
const config = require('./src/config/env.config');
const serverConfig = require('./src/config/server.config');
const routes = require('./src/routes');
const { errorHandler, notFoundHandler } = require('./src/middleware/error.middleware');
const { requestLogger } = require('./src/middleware/logger.middleware');

const app = express();

// Security & Middleware
app.use(serverConfig.helmet);
app.use(serverConfig.cors);
app.use(serverConfig.limiter);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(requestLogger);

// Routes
app.use(`/api/${config.API_VERSION}`, routes);

// Error Handlers
app.use(notFoundHandler);
app.use(errorHandler);

module.exports = app;