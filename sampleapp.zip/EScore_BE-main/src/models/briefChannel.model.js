const mongoose = require('mongoose');

const briefChannelSchema = new mongoose.Schema({
  briefId: {
    type: String,
    required: true
  },
  channelName: {
    type: String,
    required: true,
    trim: true
  },
  slackChannelId: {
    type: String,
    required: true,
    unique: true
  },
  isPrivate: {
    type: Boolean,
    default: true
  },
  description: {
    type: String,
    default: ''
  },
  emails: [{
    type: String,
    required: true
  }],
  invitedUsers: [{
    email: String,
    userId: String,
    name: String
  }],
  failedInvites: [{
    email: String,
    reason: String
  }],
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('BriefChannel', briefChannelSchema);