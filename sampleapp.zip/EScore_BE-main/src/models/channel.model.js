class Channel {
  constructor(name, emails, isPrivate = false, description = '') {
    this.name = name;
    this.emails = emails;
    this.isPrivate = isPrivate;
    this.description = description;
    this.createdAt = new Date();
    this.slackChannelId = null;
    this.invitedUsers = [];
    this.failedInvites = [];
  }

  setSlackChannelId(id) {
    this.slackChannelId = id;
  }

  addInvitedUser(email, userId) {
    this.invitedUsers.push({ email, userId });
  }

  addFailedInvite(email, reason) {
    this.failedInvites.push({ email, reason });
  }

  toJSON() {
    return {
      channel_name: this.name,
      channel_id: this.slackChannelId,
      is_private: this.isPrivate,
      description: this.description,
      created_at: this.createdAt,
      total_emails: this.emails.length,
      successfully_invited: this.invitedUsers.length,
      failed_invites: this.failedInvites.length,
      invited_users: this.invitedUsers,
      failed_invites_details: this.failedInvites
    };
  }
}

module.exports = Channel;