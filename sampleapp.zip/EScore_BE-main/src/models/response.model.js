class ApiResponse {
  constructor(success, data = null, error = null) {
    this.success = success;
    this.timestamp = new Date().toISOString();
    
    if (data) this.data = data;
    if (error) this.error = error;
  }

  static success(data) {
    return new ApiResponse(true, data);
  }

  static error(error) {
    return new ApiResponse(false, null, error);
  }
}

module.exports = ApiResponse;