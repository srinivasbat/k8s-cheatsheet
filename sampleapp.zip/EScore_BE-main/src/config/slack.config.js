const { WebClient } = require('@slack/web-api');
const config = require('./env.config');
const logger = require('../utils/logger');

const slackClient = new WebClient(config.SLACK_BOT_TOKEN);

const verifySlackConnection = async () => {
  try {
    const auth = await slackClient.auth.test();
    logger.info('Slack connection verified', {
      team: auth.team,
      user: auth.user,
      bot_id: auth.bot_id
    });
    return true;
  } catch (error) {
    logger.error('Failed to verify Slack connection', { error: error.message });
    throw new Error('Slack authentication failed');
  }
};

module.exports = {
  slackClient,
  verifySlackConnection
};