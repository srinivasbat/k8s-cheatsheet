const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const config = require('./env.config');
const { HTTP_STATUS, MESSAGES } = require('../utils/constants');

const limiter = rateLimit({
  windowMs: config.RATE_LIMIT_WINDOW_MS,
  max: config.RATE_LIMIT_MAX_REQUESTS,
  message: { 
    success: false, 
    error: MESSAGES.RATE_LIMIT 
  },
  statusCode: HTTP_STATUS.TOO_MANY_REQUESTS
});

const corsOptions = {
  origin: process.env.ALLOWED_ORIGINS || '*',
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type', 'X-API-Key']
};

module.exports = {
  helmet: helmet(),
  cors: cors(corsOptions),
  limiter
};