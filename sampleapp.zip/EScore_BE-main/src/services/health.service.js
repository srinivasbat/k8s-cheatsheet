const mongoose = require('mongoose');
const { slackClient } = require('../config/slack.config');
const logger = require('../utils/logger');

class HealthService {
  async checkDatabase() {
    try {
      if (mongoose.connection.readyState === 1) {
        await mongoose.connection.db.admin().ping();
        return { status: 'connected', message: 'MongoDB is healthy' };
      }
      return { status: 'disconnected', message: 'MongoDB not connected' };
    } catch (error) {
      logger.error(`Database health check failed: ${error.message}`);
      return { status: 'error', message: error.message };
    }
  }

  async checkSlack() {
    try {
      const result = await slackClient.auth.test();
      return { 
        status: 'connected', 
        message: 'Slack API is healthy',
        botId: result.user_id,
        team: result.team
      };
    } catch (error) {
      logger.error(`Slack health check failed: ${error.message}`);
      return { status: 'error', message: error.message };
    }
  }

  async getFullHealthStatus() {
    const [dbHealth, slackHealth] = await Promise.all([
      this.checkDatabase(),
      this.checkSlack()
    ]);

    const isHealthy = dbHealth.status === 'connected' && slackHealth.status === 'connected';

    return {
      status: isHealthy ? 'healthy' : 'unhealthy',
      timestamp: new Date().toISOString(),
      services: {
        database: dbHealth,
        slack: slackHealth
      }
    };
  }
}

module.exports = new HealthService();