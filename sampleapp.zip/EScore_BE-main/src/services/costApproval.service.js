const { slackClient } = require('../config/slack.config');
const logger = require('../utils/logger');

class CostApprovalService {
  /**
   * Send cost approval message with Approve/Reject buttons
   */
  async sendCostApproval(channelId, amount, message) {
    try {
      logger.info('Sending cost approval request', {
        channelId,
        amount,
        messageLength: message.length
      });

      const result = await slackClient.chat.postMessage({
        channel: channelId,
        text: `Cost Approval Request: ${amount}`,
        blocks: [
          {
            type: 'header',
            text: {
              type: 'plain_text',
              text: '💰 Cost Approval Request',
              emoji: true
            }
          },
          {
            type: 'section',
            fields: [
              {
                type: 'mrkdwn',
                text: `*Amount:*\n${amount}`
              },
              {
                type: 'mrkdwn',
                text: `*Status:*\n⏳ Pending Approval`
              }
            ]
          },
          {
            type: 'section',
            text: {
              type: 'mrkdwn',
              text: `*Details:*\n${message}`
            }
          },
          {
            type: 'divider'
          },
          {
            type: 'actions',
            block_id: 'cost_approval_actions',
            elements: [
              {
                type: 'button',
                text: {
                  type: 'plain_text',
                  text: '✅ Approve',
                  emoji: true
                },
                style: 'primary',
                value: JSON.stringify({
                  action: 'approve',
                  amount: amount,
                  message: message,
                  timestamp: Date.now()
                }),
                action_id: 'cost_approve_button'
              },
              {
                type: 'button',
                text: {
                  type: 'plain_text',
                  text: '❌ Reject',
                  emoji: true
                },
                style: 'danger',
                value: JSON.stringify({
                  action: 'reject',
                  amount: amount,
                  message: message,
                  timestamp: Date.now()
                }),
                action_id: 'cost_reject_button'
              }
            ]
          },
          {
            type: 'context',
            elements: [
              {
                type: 'mrkdwn',
                text: `Requested at: ${new Date().toLocaleString()}`
              }
            ]
          }
        ]
      });

      logger.info('Cost approval message sent successfully', {
        channelId,
        messageTs: result.ts,
        amount
      });

      return {
        success: true,
        message_id: result.ts,
        channel_id: channelId,
        amount: amount,
        status: 'pending'
      };
    } catch (error) {
      logger.error('Failed to send cost approval message', {
        channelId,
        amount,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * Handle cost approval - Called when Approve button is clicked
   */
  async handleApproval(userId, channelId, amount, message, messageTs) {
    try {
      logger.info('Processing cost approval', {
        userId,
        channelId,
        amount
      });

      // Get user info
      const userInfo = await slackClient.users.info({ user: userId });
      const approverName = userInfo.user.real_name || userInfo.user.name;

      // Update the original message to show approved status
      await slackClient.chat.update({
        channel: channelId,
        ts: messageTs,
        text: `Cost Approval: ${amount} - APPROVED`,
        blocks: [
          {
            type: 'header',
            text: {
              type: 'plain_text',
              text: '✅ Cost Approved',
              emoji: true
            }
          },
          {
            type: 'section',
            fields: [
              {
                type: 'mrkdwn',
                text: `*Amount:*\n${amount}`
              },
              {
                type: 'mrkdwn',
                text: `*Status:*\n✅ Approved`
              }
            ]
          },
          {
            type: 'section',
            text: {
              type: 'mrkdwn',
              text: `*Details:*\n${message}`
            }
          },
          {
            type: 'divider'
          },
          {
            type: 'section',
            text: {
              type: 'mrkdwn',
              text: `*Approved by:* ${approverName}\n*Approved at:* ${new Date().toLocaleString()}`
            }
          }
        ]
      });

      logger.info('Cost approval processed successfully', {
        userId,
        approverName,
        amount
      });

      return {
        success: true,
        status: 'approved',
        approved_by: approverName,
        approved_at: new Date().toISOString(),
        amount: amount
      };
    } catch (error) {
      logger.error('Failed to process approval', {
        userId,
        channelId,
        error: error.message
      });
      throw error;
    }
  }

  /**
   * Handle cost rejection - Called when Reject button is clicked
   */
  async handleRejection(userId, channelId, amount, message, messageTs) {
    try {
      logger.info('Processing cost rejection', {
        userId,
        channelId,
        amount
      });

      // Get user info
      const userInfo = await slackClient.users.info({ user: userId });
      const rejectorName = userInfo.user.real_name || userInfo.user.name;

      // Update the original message to show rejected status
      await slackClient.chat.update({
        channel: channelId,
        ts: messageTs,
        text: `Cost Approval: ${amount} - REJECTED`,
        blocks: [
          {
            type: 'header',
            text: {
              type: 'plain_text',
              text: '❌ Cost Rejected',
              emoji: true
            }
          },
          {
            type: 'section',
            fields: [
              {
                type: 'mrkdwn',
                text: `*Amount:*\n${amount}`
              },
              {
                type: 'mrkdwn',
                text: `*Status:*\n❌ Rejected`
              }
            ]
          },
          {
            type: 'section',
            text: {
              type: 'mrkdwn',
              text: `*Details:*\n${message}`
            }
          },
          {
            type: 'divider'
          },
          {
            type: 'section',
            text: {
              type: 'mrkdwn',
              text: `*Rejected by:* ${rejectorName}\n*Rejected at:* ${new Date().toLocaleString()}`
            }
          }
        ]
      });

      logger.info('Cost rejection processed successfully', {
        userId,
        rejectorName,
        amount
      });

      return {
        success: true,
        status: 'rejected',
        rejected_by: rejectorName,
        rejected_at: new Date().toISOString(),
        amount: amount
      };
    } catch (error) {
      logger.error('Failed to process rejection', {
        userId,
        channelId,
        error: error.message
      });
      throw error;
    }
  }
}

module.exports = new CostApprovalService();