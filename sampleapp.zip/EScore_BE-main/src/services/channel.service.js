const slackService = require('./slack.service');
const Channel = require('../models/channel.model');
const BriefChannel = require('../models/briefChannel.model');
const logger = require('../utils/logger');
const { MESSAGES } = require('../utils/constants');

class ChannelService {
  async createChannelWithUsers(briefId, channelName, emails, isPrivate = false, description = '') {
    logger.info('Starting channel creation process', {
      briefId,
      channelName,
      emailCount: emails.length,
      isPrivate
    });

    // Check if channel already exists
    const exists = await slackService.channelExists(channelName);
    if (exists) {
      throw new Error(MESSAGES.CHANNEL_EXISTS);
    }

    // Create channel model
    const channel = new Channel(channelName, emails, isPrivate, description);

    // Step 1: Look up all users by email
    const { found, notFound } = await slackService.getUsersByEmails(emails);

    if (found.length === 0) {
      throw new Error(`No valid users found for provided emails. Users must already be members of the Slack workspace. Not found: ${notFound.map(u => u.email).join(', ')}`);
    }

    if (notFound.length > 0) {
      logger.warn('Some users not found in workspace', {
        notFound: notFound.map(u => u.email)
      });
    }

    // Step 2: Create the channel
    const channelResult = await slackService.createChannel(channelName, isPrivate);
    channel.setSlackChannelId(channelResult.channelId);

    // Step 3: Set channel description if provided
    if (description) {
      await slackService.setChannelTopic(channelResult.channelId, description);
    }

    // Step 4: Invite all found users to the channel
    const userIds = found.map(user => user.userId);
    const inviteResults = await slackService.inviteUsersToChannel(
      channelResult.channelId,
      userIds
    );

    // Track successful and failed invites
    inviteResults.successful.forEach((result) => {
      const user = found.find(u => u.userId === result.userId);
      if (user) {
        channel.addInvitedUser(user.email, user.userId);
      }
    });

    inviteResults.failed.forEach((result) => {
      const user = found.find(u => u.userId === result.userId);
      if (user) {
        channel.addFailedInvite(user.email, result.error);
      }
    });

    // Add users not found in workspace
    notFound.forEach((user) => {
      channel.addFailedInvite(user.email, 'User not found in workspace');
    });

    // Step 5: Post welcome message
    await slackService.postWelcomeMessage(channelResult.channelId, emails);

    // Step 6: Save to database
    const briefChannel = new BriefChannel({
      briefId,
      channelName,
      slackChannelId: channelResult.channelId,
      isPrivate,
      description,
      emails,
      invitedUsers: found.map(user => ({
        email: user.email,
        userId: user.userId,
        name: user.name
      })),
      failedInvites: [
        ...inviteResults.failed.map(result => {
          const user = found.find(u => u.userId === result.userId);
          return { email: user?.email || 'unknown', reason: result.error };
        }),
        ...notFound.map(user => ({ email: user.email, reason: 'User not found in workspace' }))
      ]
    });

    await briefChannel.save();
    logger.info('Channel saved to database', { channelId: briefChannel._id });

    logger.info('Channel creation completed', {
      channelId: channel.slackChannelId,
      invitedCount: channel.invitedUsers.length,
      failedCount: channel.failedInvites.length
    });

    return { channel, dbRecord: briefChannel };
  }
}

module.exports = new ChannelService();