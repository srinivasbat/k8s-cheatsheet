const { slackClient } = require('../config/slack.config');
const logger = require('../utils/logger');

class SlackService {
  /**
   * Test bot permissions and auth
   */
  async testBotPermissions() {
    try {
      const auth = await slackClient.auth.test();
      logger.info('Bot auth test result', {
        ok: auth.ok,
        team: auth.team,
        user: auth.user,
        bot_id: auth.bot_id,
        user_id: auth.user_id
      });
      
      // Try to list conversations to test permissions
      const conversations = await slackClient.conversations.list({
        types: 'public_channel',
        limit: 5
      });
      
      logger.info('Bot can list channels', {
        channelCount: conversations.channels.length
      });
      
      return { success: true, auth, canListChannels: true };
    } catch (error) {
      logger.error('Bot permission test failed', { error: error.message });
      return { success: false, error: error.message };
    }
  }

  /**
   * Get user ID by email
   */
  async getUserByEmail(email) {
    try {
      const result = await slackClient.users.lookupByEmail({ email });
      return {
        found: true,
        userId: result.user.id,
        email: result.user.profile.email,
        name: result.user.real_name
      };
    } catch (error) {
      logger.warn(`User not found for email: ${email}`, { error: error.message });
      return {
        found: false,
        email,
        error: error.message
      };
    }
  }

  /**
   * Get all users by their emails
   */
  async getUsersByEmails(emails) {
    const results = await Promise.all(
      emails.map(email => this.getUserByEmail(email))
    );

    const found = results.filter(r => r.found);
    const notFound = results.filter(r => !r.found);

    logger.info('User lookup results', {
      total: emails.length,
      found: found.length,
      notFound: notFound.length
    });

    return { found, notFound };
  }

  /**
   * Create a new channel
   */
  async createChannel(channelName, isPrivate = false) {
    try {
      const result = await slackClient.conversations.create({
        name: channelName,
        is_private: isPrivate
      });

      logger.info('Channel created', {
        id: result.channel.id,
        name: result.channel.name,
        isPrivate: result.channel.is_private
      });

      return {
        success: true,
        channelId: result.channel.id,
        channelName: result.channel.name,
        isPrivate: result.channel.is_private
      };
    } catch (error) {
      logger.error('Failed to create channel', { 
        channelName, 
        error: error.message 
      });
      throw error;
    }
  }

  /**
   * Check if channel already exists
   */
  async channelExists(channelName) {
    try {
      const result = await slackClient.conversations.list({
        types: 'public_channel,private_channel',
        limit: 1000
      });

      const exists = result.channels.some(
        channel => channel.name.toLowerCase() === channelName.toLowerCase()
      );

      return exists;
    } catch (error) {
      logger.error('Error checking channel existence', { error: error.message });
      return false;
    }
  }

  /**
   * Set channel topic/description
   */
  async setChannelTopic(channelId, topic) {
    try {
      await slackClient.conversations.setTopic({
        channel: channelId,
        topic
      });
      logger.info('Channel topic set', { channelId, topic });
    } catch (error) {
      logger.error('Failed to set channel topic', { 
        channelId, 
        error: error.message 
      });
    }
  }

  /**
   * Invite user to channel
   */
  async inviteUserToChannel(channelId, userId) {
    try {
      await slackClient.conversations.invite({
        channel: channelId,
        users: userId
      });

      logger.info('User invited to channel', { channelId, userId });
      return { success: true, userId };
    } catch (error) {
      logger.error('Failed to invite user', { 
        channelId, 
        userId, 
        error: error.message 
      });
      return { success: false, userId, error: error.message };
    }
  }

  /**
   * Invite multiple users to channel
   */
  async inviteUsersToChannel(channelId, userIds) {
    const results = await Promise.all(
      userIds.map(userId => this.inviteUserToChannel(channelId, userId))
    );

    const successful = results.filter(r => r.success);
    const failed = results.filter(r => !r.success);

    logger.info('Bulk invite results', {
      channelId,
      total: userIds.length,
      successful: successful.length,
      failed: failed.length
    });

    return { successful, failed };
  }

  /**
   * Post welcome message to channel
   */
  async postWelcomeMessage(channelId, emails) {
    try {
      const message = {
        channel: channelId,
        text: `Welcome! This channel was created with ${emails.length} member(s).`,
        blocks: [
          {
            type: 'header',
            text: {
              type: 'plain_text',
              text: '🎉 Welcome to the new channel!'
            }
          },
          {
            type: 'section',
            text: {
              type: 'mrkdwn',
              text: `This channel was automatically created and *${emails.length} member(s)* have been invited.`
            }
          },
          {
            type: 'divider'
          },
          {
            type: 'context',
            elements: [
              {
                type: 'mrkdwn',
                text: `Created at: ${new Date().toLocaleString()}`
              }
            ]
          }
        ]
      };

      await slackClient.chat.postMessage(message);
      logger.info('Welcome message posted', { channelId });
    } catch (error) {
      logger.error('Failed to post welcome message', { 
        channelId, 
        error: error.message 
      });
    }
  }
}

module.exports = new SlackService();