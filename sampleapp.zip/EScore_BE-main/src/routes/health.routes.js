const express = require('express');
const router = express.Router();
const healthController = require('../controllers/health.controller');

router.get('/health', healthController.checkHealth);
router.get('/test-bot', async (req, res) => {
  const slackService = require('../services/slack.service');
  const result = await slackService.testBotPermissions();
  res.json(result);
});

router.get('/test-create', async (req, res) => {
  const slackService = require('../services/slack.service');
  try {
    const randomName = `test-${Date.now()}`;
    const result = await slackService.createChannel(randomName, false);
    res.json({ success: true, result });
  } catch (error) {
    res.json({ success: false, error: error.message });
  }
});

module.exports = router;