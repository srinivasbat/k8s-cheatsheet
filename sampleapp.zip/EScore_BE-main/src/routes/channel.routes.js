const express = require('express');
const router = express.Router();
const channelController = require('../controllers/channel.controller');
const { authenticateApiKey } = require('../middleware/auth.middleware');
const { validateCreateChannel } = require('../middleware/validation.middleware');

router.post(
  '/channels',
  authenticateApiKey,
  validateCreateChannel,
  channelController.createChannel
);

module.exports = router;