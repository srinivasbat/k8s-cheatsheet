const express = require('express');
const router = express.Router();
const channelController = require('../controllers/channel.controller');
const { authenticateApiKey } = require('../middleware/auth.middleware');
const { 
  validateCreateChannel,
  validateGetChannel,
  validateApprovalMessage 
} = require('../middleware/validation.middleware');

// Create channel
router.post(
  '/channels',
  authenticateApiKey,
  validateCreateChannel,
  channelController.createChannel
);

// Get channel details
router.post(
  '/channels/details',
  authenticateApiKey,
  validateGetChannel,
  channelController.getChannelDetails
);

// Send approval message
router.post(
  '/channels/approval',
  authenticateApiKey,
  validateApprovalMessage,
  channelController.sendApprovalMessage
);

module.exports = router;