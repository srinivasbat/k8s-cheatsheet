const express = require('express');
const router = express.Router();
const healthRoutes = require('./health.routes');
const channelRoutes = require('./channel.routes');

router.use(healthRoutes);
router.use(channelRoutes);

module.exports = router;