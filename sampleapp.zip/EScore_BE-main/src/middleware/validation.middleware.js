const { schemas } = require('../utils/validator');
const { HTTP_STATUS } = require('../utils/constants');
const ApiResponse = require('../models/response.model');

const validateRequest = (schema) => {
  return (req, res, next) => {
    console.log('Request body:', JSON.stringify(req.body, null, 2));
    console.log('Content-Type:', req.headers['content-type']);
    const { error, value } = schema.validate(req.body);

    if (error) {
      return res.status(HTTP_STATUS.BAD_REQUEST).json(
        ApiResponse.error(error.details[0].message)
      );
    }

    req.validatedData = value;
    next();
  };
};

module.exports = { 
  validateRequest,
  validateCreateChannel: validateRequest(schemas.createChannel),
  validateGetChannel: validateRequest(schemas.getChannel),
  validateApprovalMessage: validateRequest(schemas.approvalMessage)
};