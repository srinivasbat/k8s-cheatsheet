const config = require('../config/env.config');
const { HTTP_STATUS, MESSAGES } = require('../utils/constants');
const ApiResponse = require('../models/response.model');
const logger = require('../utils/logger');

const authenticateApiKey = (req, res, next) => {
  const apiKey = req.headers['x-api-key'];

  if (!apiKey) {
    logger.warn('API request without API key', { 
      ip: req.ip, 
      path: req.path 
    });
    return res.status(HTTP_STATUS.UNAUTHORIZED).json(
      ApiResponse.error(MESSAGES.UNAUTHORIZED)
    );
  }

  if (apiKey !== config.API_KEY) {
    logger.warn('API request with invalid API key', { 
      ip: req.ip, 
      path: req.path 
    });
    return res.status(HTTP_STATUS.FORBIDDEN).json(
      ApiResponse.error(MESSAGES.FORBIDDEN)
    );
  }

  next();
};

module.exports = { authenticateApiKey };