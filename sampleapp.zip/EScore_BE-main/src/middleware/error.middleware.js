const logger = require('../utils/logger');
const { HTTP_STATUS, MESSAGES } = require('../utils/constants');
const ApiResponse = require('../models/response.model');
const config = require('../config/env.config');

const errorHandler = (err, req, res, next) => {
  logger.error('Error occurred', {
    message: err.message,
    stack: err.stack,
    path: req.path,
    method: req.method,
    body: req.body
  });

  // Handle specific Slack errors
  if (err.data?.error === 'name_taken') {
    return res.status(HTTP_STATUS.CONFLICT).json(
      ApiResponse.error(MESSAGES.CHANNEL_EXISTS)
    );
  }

  const statusCode = err.statusCode || HTTP_STATUS.INTERNAL_ERROR;
  const message = config.NODE_ENV === 'production' 
    ? MESSAGES.SERVER_ERROR 
    : err.message;

  res.status(statusCode).json(
    ApiResponse.error(message)
  );
};

const notFoundHandler = (req, res) => {
  res.status(HTTP_STATUS.NOT_FOUND).json(
    ApiResponse.error('Route not found')
  );
};

module.exports = { errorHandler, notFoundHandler };