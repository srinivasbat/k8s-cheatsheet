const costApprovalService = require('../services/costApproval.service');
const ApiResponse = require('../models/response.model');
const { HTTP_STATUS } = require('../utils/constants');
const logger = require('../utils/logger');

class CostApprovalController {
  /**
   * Send cost approval request to Slack channel
   */
  async sendCostApproval(req, res, next) {
    try {
      const { channel_id, amount, message } = req.validatedData;

      logger.info('Cost approval request received', {
        channelId: channel_id,
        amount
      });

      const result = await costApprovalService.sendCostApproval(
        channel_id,
        amount,
        message
      );

      res.status(HTTP_STATUS.OK).json(
        ApiResponse.success({
          message: 'Cost approval request sent successfully',
          ...result
        })
      );
    } catch (error) {
      next(error);
    }
  }

  /**
   * Handle approval action from Slack
   */
  async handleApproval(req, res, next) {
    try {
      const { user_id, channel_id, amount, message, message_ts } = req.validatedData;

      logger.info('Approval action received', {
        userId: user_id,
        channelId: channel_id,
        amount
      });

      const result = await costApprovalService.handleApproval(
        user_id,
        channel_id,
        amount,
        message,
        message_ts
      );

      // TODO: Add your custom logic here
      // Example: Call external API, update database, send notifications, etc.
      logger.info('TODO: Add custom approval logic here', { result });

      res.status(HTTP_STATUS.OK).json(
        ApiResponse.success({
          message: 'Cost approval processed successfully',
          ...result
        })
      );
    } catch (error) {
      next(error);
    }
  }

  /**
   * Handle rejection action from Slack
   */
  async handleRejection(req, res, next) {
    try {
      const { user_id, channel_id, amount, message, message_ts } = req.validatedData;

      logger.info('Rejection action received', {
        userId: user_id,
        channelId: channel_id,
        amount
      });

      const result = await costApprovalService.handleRejection(
        user_id,
        channel_id,
        amount,
        message,
        message_ts
      );

      // TODO: Add your custom logic here
      // Example: Call external API, update database, send notifications, etc.
      logger.info('TODO: Add custom rejection logic here', { result });

      res.status(HTTP_STATUS.OK).json(
        ApiResponse.success({
          message: 'Cost rejection processed successfully',
          ...result
        })
      );
    } catch (error) {
      next(error);
    }
  }
}

module.exports = new CostApprovalController();