const ApiResponse = require('../models/response.model');
const { HTTP_STATUS } = require('../utils/constants');
const config = require('../config/env.config');
const healthService = require('../services/health.service');

class HealthController {
  async checkHealth(req, res) {
    try {
      const healthStatus = await healthService.getFullHealthStatus();
      
      res.status(HTTP_STATUS.OK).json(
        ApiResponse.success({
          ...healthStatus,
          environment: config.NODE_ENV,
          version: config.API_VERSION,
          uptime: process.uptime()
        })
      );
    } catch (error) {
      res.status(HTTP_STATUS.INTERNAL_SERVER_ERROR).json(
        ApiResponse.error('Health check failed', error.message)
      );
    }
  }
}

module.exports = new HealthController();