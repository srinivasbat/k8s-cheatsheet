const channelService = require('../services/channel.service');
const ApiResponse = require('../models/response.model');
const { HTTP_STATUS, MESSAGES } = require('../utils/constants');
const logger = require('../utils/logger');

class ChannelController {
  async createChannel(req, res, next) {
    try {
      const { brief_id, channel_name, emails, is_private, description } = req.validatedData;
      

      logger.info('Channel creation request', {
        briefId: brief_id,
        channelName: channel_name,
        emailCount: emails.length,
        isPrivate: is_private
      });

      const result = await channelService.createChannelWithUsers(
        brief_id,
        channel_name,
        emails,
        is_private,
        description
      );

      const responseData = {
        message: MESSAGES.SUCCESS,
        ...result.channel.toJSON(),
        database_id: result.dbRecord._id
      };

      res.status(HTTP_STATUS.CREATED).json(
        ApiResponse.success(responseData)
      );
    } catch (error) {
      next(error);
    }
  }
  
}

module.exports = new ChannelController();