module.exports = {
  HTTP_STATUS: {
    OK: 200,
    CREATED: 201,
    BAD_REQUEST: 400,
    UNAUTHORIZED: 401,
    FORBIDDEN: 403,
    NOT_FOUND: 404,
    CONFLICT: 409,
    TOO_MANY_REQUESTS: 429,
    INTERNAL_ERROR: 500
  },

  MESSAGES: {
    SUCCESS: 'Channel created successfully',
    UNAUTHORIZED: 'API key is required',
    FORBIDDEN: 'Invalid API key',
    RATE_LIMIT: 'Too many requests, please try again later',
    CHANNEL_EXISTS: 'Channel with this name already exists',
    INVALID_EMAILS: 'Some emails could not be found in workspace',
    SERVER_ERROR: 'Internal server error'
  },

  CHANNEL_DEFAULTS: {
    MAX_NAME_LENGTH: 80,
    MAX_DESCRIPTION_LENGTH: 250
  }
};