const Joi = require('joi');

const schemas = {
  createChannel: Joi.object({
    brief_id: Joi.string()
      .required()
      .messages({
        'string.empty': 'Brief ID is required'
      }),
      
    channel_name: Joi.string()
      .pattern(/^[a-z0-9-_]+$/)
      .min(1)
      .max(80)
      .required()
      .messages({
        'string.pattern.base': 'Channel name must contain only lowercase letters, numbers, hyphens, and underscores',
        'string.max': 'Channel name must be 80 characters or less'
      }),
    
    emails: Joi.array()
      .items(Joi.string().email())
      .min(1)
      .required()
      .messages({
        'array.min': 'At least one email is required',
        'string.email': 'Invalid email format'
      }),
    
    is_private: Joi.boolean().default(false),
    
    description: Joi.string()
      .max(250)
      .optional()
      .allow('')
  }),
  getChannel: Joi.object({
    channel_id: Joi.string()
      .required()
      .messages({
        'string.empty': 'Channel ID is required'
      })
  }),

  approvalMessage: Joi.object({
    channel_id: Joi.string()
      .required()
      .messages({
        'string.empty': 'Channel ID is required'
      }),
    
    message: Joi.string()
      .min(1)
      .max(3000)
      .required()
      .messages({
        'string.empty': 'Message is required',
        'string.max': 'Message must be 3000 characters or less'
      }),
    
    approver_emails: Joi.array()
      .items(Joi.string().email())
      .min(1)
      .required()
      .messages({
        'array.min': 'At least one approver email is required',
        'string.email': 'Invalid email format'
      })
  })
};

module.exports = { schemas };