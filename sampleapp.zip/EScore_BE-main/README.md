# Slack Channel Creator
Production-ready setup.

# health check end points
/health 
localhoast - http://localhost:3000/api/v1/health



